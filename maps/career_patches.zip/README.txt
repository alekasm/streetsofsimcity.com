This archive contains patched cities with the following fixes
City 6 - missing road tile (alekasm, 12 Jan 2020)
City 29 - missing road tile (alekasm, 20 Apr 2020)

www.simcopter.net
View website for images of patched areas

INSTALL
1. Unzip
2. Rename "cityXX-patched.sc2" to the original name "cityXX.sc2"
3. Go to your SimCopter folder/cities/careers
4. Copy paste your renamed sc2 files into this folder, overwriting the old files
Optional: Create a backup of the original cities